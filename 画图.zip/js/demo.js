class Demo {
    constructor ({
        dom,
        data,
        showBorder = false,
        titleColor = '#fff',
        titleFontSize = 20
    }) {
        if (!dom) {
            console.error('请传入dom')
            return
        }
        createjs.Ticker.timingMode = createjs.Ticker.RAF
        this.showBorder = showBorder
        this.dom = dom
        this.data = data
        this.titleFontSize = titleFontSize
        this.titleColor = titleColor
        this.canvas = document.createElement('canvas')
        this.canvas.width = this.dom.offsetWidth
        this.canvas.height = this.dom.offsetHeight
        this.dom.appendChild(this.canvas)
        // 创建舞台
        this.stage = new createjs.Stage(this.canvas)
        createjs.Ticker.on('tick', this.stage)
        this.nodeMap = {
            containerArr: [],
            picArr: [], 
            titleArr: [],
            rectArr: []
        }
        this.createContent()
        this.resize()
        this.addEvent()
    }
    // 创建容器
    createContent () {
        this.data.forEach(d => {
            // 容器
            let container = new createjs.Container()
            // 图形
            let pic = new createjs.Shape()
            // 名字
            let title = new createjs.Text()
            pic.name = title.name = d.name
            container.addChild(pic, title)
            this.stage.addChild(container)
            this.nodeMap.containerArr.push(container)
            this.nodeMap.picArr.push(pic)
            this.nodeMap.titleArr.push(title)
            if (this.showBorder) {
                let rect = new createjs.Shape();
                this.stage.addChild(rect);
                this.nodeMap.rectArr.push(rect);
            }
        })
    }
    // 布局
    initLayout () {
        this.data.forEach((d, i) => {
            let container = this.nodeMap.containerArr[i]
            container.x = d.layout[0]
            container.y = d.layout[1]
            container.width = d.size[0]
            container.height = d.size[1]
            // 图形
            let pic = this.nodeMap.picArr[i]
            d.pic.forEach((p, index) => {
                if (index === 0) {
                    pic.graphics.setStrokeStyle(d.lineWidth, 'round').beginStroke("#fff").beginFill("#666").mt(p[0], p[1])
                } else {
                    pic.graphics.lt(p[0], p[1])
                }
            })
            // 边框
            if (this.showBorder) {
                let rect = this.nodeMap.rectArr[i]
                rect.graphics.clear().beginStroke('red').rect(container.x, container.y, container.width, container.height);
            }
            // 标题
            let title = this.nodeMap.titleArr[i]
            title.x = d.titlePos[0]
            title.y = d.titlePos[1]
            title.textAlign = 'center';
            title.textBaseline = 'top';
            title.font = `${this.titleFontSize}px Arial`;
            title.text = d.name;
            title.color = this.titleColor;
            title.textBaseline = 'bottom';
        })
    }
    // 添加事件
    addEvent () {
        this.stage.addEventListener("click", function(e) {
            alert('点击了图形' + e.target.name)
            console.log(e.target.name);
        })
    }
    // 自适应
    resize () {
        this.canvas.width = this.dom.offsetWidth
        this.canvas.height = this.dom.offsetHeight
        this.initLayout();
    }
}
